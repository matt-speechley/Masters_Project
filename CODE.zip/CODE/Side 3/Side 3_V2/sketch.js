//This is the sketch for visualising PM2.5 emissions from a Petrol Car. The other visualisations use the same code with different parameters.

//Set up Font and OBJ Models
let arial;
let suv;
let brake;
let wheel;
let exhaust;
particles_tyre = [];
particles_brakes = [];
particles_exhaust = [];

//Load Font and OBJ Models
function preload() {
  arial = loadFont('assets/arial.ttf');
  suv = loadModel('SUV.obj', true);
  brake = loadModel('brake.obj', true);
  wheel = loadModel('Wheel.obj', true);
  exhaust = loadModel('exhaust.obj', true);
}

//Setup Canvas and text formatting options
function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  angleMode(DEGREES);
  textFont(arial);
  textSize(windowWidth/24);
  textAlign(CENTER, CENTER);
}

// Draw Function
function draw() {
  //Used to record frame by frame footage, can be commented out
  if (frameCount === 1){
    capturer.start()
  }

  // Set up lighting conditions
  background(0);
  ambientLight(200);
  directionalLight(255, 255, 255, 0, 0, 1);
  
  // random used so that stream of particles isn't constant
  // particles are given a location, colour and added to a list of onscreen particles.
  if (random(1) > 0.97) {

    var x_tyre = random(-windowWidth/3 - 10, -windowWidth/3 + 10)
    var y_tyre = random(-windowHeight/4 - 10, -windowHeight/4 +10)
    var z_tyre = random(-100, 0)
    var pos_tyre = createVector(x_tyre, y_tyre, z_tyre)

    var x_brakes = random(windowWidth/3 - 10, windowWidth/3 + 10)
    var y_brakes = random(-windowHeight/4 - 10, -windowHeight/4 +10)
    var z_brakes = random(-100, 0)
    var pos_brakes = createVector(x_brakes, y_brakes, z_brakes)

    var x_exhaust = random(0 - 10, 0 + 10)
    var y_exhaust = random(windowHeight/3 - 10, windowHeight/3 +10)
    var z_exhaust = random(-100, 0)
    var pos_exhaust = createVector(x_exhaust, y_exhaust, z_exhaust)

    for (var i = 0; i < 50; i++) { //Size of loop = number of particles in each burst
      var r_tyre = (0 + random(0, 50));
      var g_tyre = (180 + random(-50, 50));
      var b_tyre = (216 + random(-50, 50));
      var c_tyre = color(r_tyre,g_tyre,b_tyre)
      var p_tyre = new Particle(pos_tyre, c_tyre)
      particles_tyre.push(p_tyre)
      }
    for (var i = 0; i < 6; i++) {
      var r_brakes = (255 + random(-50, 0));
      var g_brakes = (0 + random(0, 50));
      var b_brakes = (43 + random(0, 50));
      var c_brakes = color(r_brakes,g_brakes,b_brakes)
      var p_brakes = new Particle(pos_brakes, c_brakes)
      particles_brakes.push(p_brakes)
    }
    for (var i = 0; i < 6; i++) {
      var r_exhaust = (112 + random(-50, 50));
      var g_exhaust = (224 + random(-50, 50));
      var b_exhaust = (0 + random(0, 50));
      var c_exhaust = color(r_exhaust,g_exhaust,b_exhaust)
      var p_exhaust = new Particle(pos_exhaust, c_exhaust)
      particles_exhaust.push(p_exhaust)
    }
  }

  // particles dissapear once a certain distance away from their source
  for (var i = particles_tyre.length -1; i >= 0; i--) {
    if (dist(particles_tyre[i].pos.x, particles_tyre[i].pos.y, particles_tyre[i].pos.z, -windowWidth/3, -windowHeight/4, 0) < 300) {
      particles_tyre[i].update()
      particles_tyre[i].show()
    } else {
    particles_tyre.splice(i,1)
    }
  }
  for (var i = particles_brakes.length -1; i >= 0; i--) {
    if (dist(particles_brakes[i].pos.x, particles_brakes[i].pos.y, particles_brakes[i].pos.z, windowWidth/3, -windowHeight/4, 0) < 300) {
      particles_brakes[i].update()
      particles_brakes[i].show()
    } else {
    particles_brakes.splice(i,1)
    }
  }
  for (var i = particles_exhaust.length -1; i >= 0; i--) {
    if (dist(particles_exhaust[i].pos.x, particles_exhaust[i].pos.y, particles_exhaust[i].pos.z, 0, windowHeight/3, 0) < 300) {
      particles_exhaust[i].update()
      particles_exhaust[i].show()
    } else {
    particles_exhaust.splice(i,1)
    }
  }

  //position and display OBJ models
  translate(0, 60, 0);
  normalMaterial();
  push();
  rotateX(90);
  rotateZ(frameCount * 0.1);
  scale(2.5);
  model(suv);
  pop();
  translate(0, -10, 0);
  
  translate(windowWidth/3, -windowHeight/3.2, 0);
  push();
  rotateY(frameCount * 0.1);
  model(brake);
  pop();

  translate(-2*windowWidth/3, 0, 0);
  push();
  rotateY(frameCount * 0.1);
  model(wheel);
  pop();

  translate(windowWidth/3, windowHeight/1.8, 0);
  push();
  rotateY(frameCount * 0.1);
  scale(2);
  model(exhaust);
  pop();


  //Display text
  textSize(windowWidth/24);
  text('Petrol Car PM2.5 Emission Sources', 0, -2.1*windowHeight/3);
  textSize(windowWidth/34);
  text('Tyre Abrasion and\nRoad Resuspension\n18mg/km', -windowWidth/3, -windowHeight/2.6);
  text('Brake Abrasion\n2.2mg/km', windowWidth/3, -windowHeight/2.6);
  text('Exhaust Emissions\n3.0mg/km', 0, windowHeight/6.5);
  
  //End screen recording after 900 frames
  if (frameCount < 900){
    capturer.capture(canvas)
  } else if (frameCount === 900) {
    capturer.save()
    capturer.stop()
  }
}

//Class used for particles
class Particle {
  constructor(pos, c) {
    this.pos = createVector(pos.x, pos.y, pos.z)
    this.vel = p5.Vector.random3D().normalize().mult(random(3,5))
    this.c = c
    this.w = random(0.2, 2)
  }
  update() {
    this.pos.add(this.vel)
  }
  show() {
    push()
    noStroke()
    fill(this.c)
    translate(this.pos.x, this.pos.y, this.pos.z)
    sphere(this.w)
    pop()
  }
}