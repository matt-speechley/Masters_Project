//Sketch for visualisation of height density of air pollution.
//Uses multiple particle clouds stacked, in order to get a gradient effect

let particles = [];
let particles2 = [];
let particles3 = [];
let particles4 = [];
let particles5 = [];
let particles6 = [];
let woman;
let child;
let stroller;

//Loaf font and OBJs
function preload() {
  woman = loadModel('woman.obj');
  child = loadModel('child.obj');
  stroller = loadModel('stroller.obj');
  arial = loadFont('assets/arial.ttf');
}

function setup() {
	createCanvas(windowWidth, windowHeight, WEBGL);
	angleMode(DEGREES);
  textFont(arial);
  textAlign(CENTER, CENTER);
  randomizeParticles();
  randomizeParticles2();
  randomizeParticles3();
  randomizeParticles4();
  randomizeParticles5();
  randomizeParticles6();
}

function draw() {
  //Screen recording
	if (frameCount === 1){
    capturer.start()
  }

  background(0);
  
  ambientLight(255);
  directionalLight(255, 255, 255, 0, 0, 1);
  normalMaterial(0, -1);
  
  // Position OBJs
  rotateX(180)
  rotateY(180)
  translate(windowWidth/3,-windowHeight/2.6,1)
  rotateY(-60)
  scale(250);
	model(woman);
  scale(1/250)
  rotateY(60)
  
  translate(-windowWidth/5,0)
  scale(230);
  model(child);
  scale(1/230)
  translate(windowWidth/5,0)
  
  rotateY(-30)
  translate(-windowWidth/3,windowHeight/3.3, 220)
  scale(2.1);
  model(stroller);
  scale(1/2.1);
  translate(windowWidth/3,-windowHeight/3.3,-220)
  rotateY(30)

  translate(-windowWidth/3,windowHeight/2.6,-1)
  

  translate(0, windowHeight/10)
  
  rotateX(180)

  stroke(100)
  translate(0,0,60)

  // Draw graph lines and text

  line(-windowWidth,0,windowWidth,0)
  line(-windowWidth,windowHeight/6,windowWidth,windowHeight/6)
  line(-windowWidth,windowHeight/3,windowWidth,windowHeight/3)
  line(-windowWidth,-windowHeight/6,windowWidth,-windowHeight/6)
  line(-windowWidth,-windowHeight/3,windowWidth,-windowHeight/3)
  translate(0,0,-60)
  noStroke()

  rotateY(180)
  textSize(windowWidth/60);
  text('1.5m',-windowWidth/2.15,-10)
  text('1.0m',-windowWidth/2.15, windowHeight/6 -18)
  text('0.5m',-windowWidth/2.15, windowHeight/3 -28)
  text('2.0m',-windowWidth/2.15, -windowHeight/6)
  text('2.5m',-windowWidth/2.15, -windowHeight/3 +10)
  text('Air Pollutant Level\n(at standard measurment height)',windowWidth/2.75,0)
  text('+20%',windowWidth/2.15, windowHeight/6 -18)
  text('+40%',windowWidth/2.15, windowHeight/3 -28)
  text('-20%',windowWidth/2.15, -windowHeight/6)
  text('-40%',windowWidth/2.15, -windowHeight/3 +10)
  textSize(windowWidth/40);
  text('Roadside air pollution variation due to height', 0, windowHeight/1.8)

  //update particle clouds
	for(let p of particles) {
		p.update(deltaTime);// timestep pos
		applyBC(p);
		p.draw();
	}

	for(let p2 of particles2) {
		p2.update(deltaTime);// timestep pos
		applyBC2(p2);
		p2.draw();
	}

  for(let p3 of particles3) {
		p3.update(deltaTime);// timestep pos
		applyBC3(p3);
		p3.draw();
	}

	for(let p4 of particles4) {
		p4.update(deltaTime);// timestep pos
		applyBC4(p4);
		p4.draw();
	}	

  for(let p5 of particles5) {
		p5.update(deltaTime);// timestep pos
		applyBC5(p5);
		p5.draw();
	}	

  for(let p6 of particles6) {
		p6.update(deltaTime);// timestep pos
		applyBC6(p6);
		p6.draw();
	}

	// end screen recording
  if (frameCount < 1800){
    capturer.capture(canvas)
  } else if (frameCount === 1800) {
    capturer.save()
    capturer.stop()
  }
}

//wrap particles when they leave their boundaries so they stay on screen
function applyBC(particle) {
	let A = particle;
	if(A.pos.x < -width/2)      A.pos.x += width;
	if(A.pos.x > width/2)  A.pos.x -= width;
	if(A.pos.y < -height/2) 		 A.pos.y += height;
	if(A.pos.y > height/2) A.pos.y -= height;
}

function applyBC2(particle) {
	let A = particle;
	if(A.pos.x < -width/2)      A.pos.x += width;
	if(A.pos.x > width/2)  A.pos.x -= width;
	if(A.pos.y < -height/3) 		 A.pos.y += 5*height/6;
	if(A.pos.y > height/2) A.pos.y -= 5*height/6;
}

function applyBC3(particle) {
	let A = particle;
	if(A.pos.x < -width/2)      A.pos.x += width;
	if(A.pos.x > width/2)  A.pos.x -= width;
	if(A.pos.y < -height/6) 		 A.pos.y += 2*height/3;
	if(A.pos.y > height/2) A.pos.y -= 2*height/3;
}

function applyBC4(particle) {
	let A = particle;
	if(A.pos.x < -width/2)      A.pos.x += width;
	if(A.pos.x > width/2)  A.pos.x -= width;
	if(A.pos.y < 0) 		 A.pos.y += height/2;
	if(A.pos.y > height/2) A.pos.y -= height/2;
}

function applyBC5(particle) {
	let A = particle;
	if(A.pos.x < -width/2)      A.pos.x += width;
	if(A.pos.x > width/2)  A.pos.x -= width;
	if(A.pos.y < height/6) 		 A.pos.y += height/3;
	if(A.pos.y > height/2) A.pos.y -= height/3;
}

function applyBC6(particle) {
	let A = particle;
	if(A.pos.x < -width/2)      A.pos.x += width;
	if(A.pos.x > width/2)  A.pos.x -= width;
	if(A.pos.y < height/3) 		 A.pos.y += height/6;
	if(A.pos.y > height/2) A.pos.y -= height/6;
}

//create particles
function randomizeParticles() {
	particles = [];
	for(let k=0; k<200; k++)  
		particles.push(createRandomParticle());
}

function randomizeParticles2() {
	particles2 = [];
	for(let k=0; k<200; k++)  
		particles2.push(createRandomParticle2());
}

function randomizeParticles3() {
	particles3 = [];
	for(let k=0; k<200; k++)  
		particles3.push(createRandomParticle3());
}

function randomizeParticles4() {
	particles4 = [];
	for(let k=0; k<270; k++)  
		particles4.push(createRandomParticle4());
}

function randomizeParticles5() {
	randomizeParticles5 = [];
	for(let k=0; k<270; k++)  
		particles5.push(createRandomParticle5());
}

function randomizeParticles6() {
	particles6 = [];
	for(let k=0; k<250; k++)  
		particles6.push(createRandomParticle6());
}

// A simple particle class
class Particle {
	constructor(x,y,vx,vy,r,c) {
		this.pos = createVector(x,y);
		this.vel = createVector(vx,vy);
		this.r  = r;//radius
		this.c  = c;//color
	}
	update(dt) {
		// Update velocity:
		this.vel.x += random(-0.005,0.005)
		this.vel.y += random(-0.005,0.005)
    if (this.vel.x >= 0.02){
      this.vel.x = 0.02
    }
    if (this.vel.x <= -0.02){
      this.vel.x = -0.02
    }

    if (this.vel.y >= 0.02){
      this.vel.y = 0.02
    }
    if (this.vel.y <= -0.02){
      this.vel.y = -0.02
    }
		// Update position:
		this.pos.x += dt * this.vel.x;
		this.pos.y += dt * this.vel.y;
	}
	
	draw() {
		fill(this.c);
		circle(this.pos.x, this.pos.y, this.r);
	}
}

// create random size and colour particle
function createRandomParticle() {
	let radius  = abs(random(1.5,2));
	colorMode(RGB,255);
	return new Particle(random(-width/2, width/2), random(-height/2, height/2), 
											0, 0, radius, 
											color(244,255,253));
}

function createRandomParticle2() {
	let radius  = abs(random(2,2.5));
	colorMode(RGB,255);
	return new Particle(random(-width/2, width/2), random(-height/2, height/2), 
											0, 0, radius, 
											color(249,220,90));
}

function createRandomParticle3() {
	let radius  = abs(random(2.5,3));
	colorMode(RGB,255);
	return new Particle(random(-width/2, width/2), random(-height/2, height/2), 
											0, 0, radius, 
											color(243,129,85));
}

function createRandomParticle4() {
	let radius  = abs(random(3,3.5));
	colorMode(RGB,255);
	return new Particle(random(-width/2, width/2), random(-height/2, height/2), 
											0, 0, radius, 
											color(237,37,78));
}

function createRandomParticle5() {
	let radius  = abs(random(3.5,4.5));
	colorMode(RGB,255);
	return new Particle(random(-width/2, width/2), random(-height/2, height/2), 
											0, 0, radius, 
											color(146,23,49));
}

function createRandomParticle6() {
	let radius  = abs(random(4.5,5));
	colorMode(RGB,255);
	return new Particle(random(-width/2, width/2), random(-height/2, height/2), 
											0, 0, radius, 
											color(74,32,64));
}