library(raster)
library(rgdal)
library(ggplot2)